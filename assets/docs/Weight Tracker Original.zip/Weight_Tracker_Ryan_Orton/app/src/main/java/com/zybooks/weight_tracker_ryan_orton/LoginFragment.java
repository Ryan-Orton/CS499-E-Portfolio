package com.zybooks.weight_tracker_ryan_orton;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class LoginFragment extends Fragment {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button   loginButton;
    private Button   createAccountButton;
    private DBHelper dbHelper;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_login, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper            = new DBHelper(requireContext());
        usernameEditText    = view.findViewById(R.id.usernameEditText);
        passwordEditText    = view.findViewById(R.id.passwordEditText);
        loginButton         = view.findViewById(R.id.loginButton);
        createAccountButton = view.findViewById(R.id.createAccountButton);

        // disable login until both fields have text
        loginButton.setEnabled(false);
        TextWatcher watcher = new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) { }
            @Override public void afterTextChanged(Editable s) { }
            @Override
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                String u = usernameEditText.getText().toString().trim();
                String p = passwordEditText.getText().toString().trim();
                loginButton.setEnabled(!u.isEmpty() && !p.isEmpty());
            }
        };
        usernameEditText.addTextChangedListener(watcher);
        passwordEditText.addTextChangedListener(watcher);

        // LOGIN → WeightFragment
        loginButton.setOnClickListener(v -> {
            String u = usernameEditText.getText().toString().trim();
            String p = passwordEditText.getText().toString().trim();
            if (dbHelper.checkUser(u, p)) {
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.fragmentContainerView, new WeightFragment())
                        .addToBackStack(null)
                        .commit();
            }
            else {
                Toast.makeText(getContext(),
                        "Invalid username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // CREATE ACCOUNT → CreateAccountFragment
        createAccountButton.setOnClickListener(v -> {
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragmentContainerView,
                            new CreateAccountFragment())
                    .addToBackStack(null)
                    .commit();
        });
    }
}