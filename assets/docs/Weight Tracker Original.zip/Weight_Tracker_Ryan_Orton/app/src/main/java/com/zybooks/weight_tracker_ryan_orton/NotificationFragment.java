package com.zybooks.weight_tracker_ryan_orton;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class NotificationFragment extends Fragment {

    private static final int SMS_PERMISSION_REQUEST_CODE = 123;

    private TextView permissionStatusTextView;
    private Button requestPermissionButton;

    public NotificationFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_notification, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Link UI elements
        permissionStatusTextView = view.findViewById(R.id.permissionStatusTextView);
        requestPermissionButton = view.findViewById(R.id.requestPermissionButton);

        // Initial permission status check
        updatePermissionStatus();

        // Set click listener to request permission
        requestPermissionButton.setOnClickListener(v -> {
            requestPermissions(
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE
            );
        });
    }

    // Helper method to update status text
    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            permissionStatusTextView.setText("SMS Permission: GRANTED");
        } else {
            permissionStatusTextView.setText("SMS Permission: DENIED");
        }
    }

    // Handle permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                permissionStatusTextView.setText("SMS Permission: GRANTED");
            } else {
                permissionStatusTextView.setText("SMS Permission: DENIED");
            }
        }
    }
}