package com.zybooks.weight_tracker_ryan_orton;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DB_NAME    = "app.db";
    private static final int    DB_VERSION = 3;

    // -- users table --
    private static final String TABLE_USERS  = "users";
    private static final String COL_USER     = "username";
    private static final String COL_PASS     = "password";

    // -- weights table --
    private static final String TABLE_WEIGHTS = "weights";
    private static final String COL_ID        = "id";
    private static final String COL_DATE      = "date";
    private static final String COL_WEIGHT    = "weight";

    // -- goal table --
    private static final String TABLE_GOAL    = "goal";
    private static final String COL_GOAL_ID   = "id";
    private static final String COL_GOAL_WT   = "goalWeight";

    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // users
        db.execSQL("CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER + " TEXT PRIMARY KEY, " +
                COL_PASS + " TEXT NOT NULL)");

        // weights
        db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DATE + " TEXT NOT NULL, " +
                COL_WEIGHT + " REAL NOT NULL)");

        // goal
        db.execSQL("CREATE TABLE " + TABLE_GOAL + " (" +
                COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_GOAL_WT + " REAL NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE " + TABLE_WEIGHTS + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_DATE + " TEXT NOT NULL, " +
                    COL_WEIGHT + " REAL NOT NULL)");
        }
        if (oldVersion < 3) {
            db.execSQL("CREATE TABLE " + TABLE_GOAL + " (" +
                    COL_GOAL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_GOAL_WT + " REAL NOT NULL)");
        }
    }

    //
    // === User methods ===
    //

    /** Inserts a new user; returns true if successful. */
    public boolean addUser(String user, String pass) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_USER, user);
        cv.put(COL_PASS, pass);
        long result = db.insert(TABLE_USERS, null, cv);
        return result != -1;
    }

    /** Returns true if username/password match. */
    public boolean checkUser(String user, String pass) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_USERS,
                new String[]{ COL_USER },
                COL_USER + "=? AND " + COL_PASS + "=?",
                new String[]{ user, pass },
                null, null, null
        );
        boolean exists = c.getCount() > 0;
        c.close();
        return exists;
    }

    //
    // === Weight methods ===
    //

    /** Inserts a weight entry; returns new row ID or -1. */
    public long addWeight(String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_DATE, date);
        cv.put(COL_WEIGHT, weight);
        return db.insert(TABLE_WEIGHTS, null, cv);
    }

    /** Fetches all weight entries ordered by date descending. */
    public List<WeightEntry> getAllWeights() {
        List<WeightEntry> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_WEIGHTS,
                new String[]{ COL_ID, COL_DATE, COL_WEIGHT },
                null, null, null, null,
                COL_DATE + " DESC"
        );
        while (c.moveToNext()) {
            int    id     = c.getInt(c.getColumnIndexOrThrow(COL_ID));
            String date   = c.getString(c.getColumnIndexOrThrow(COL_DATE));
            double wt     = c.getDouble(c.getColumnIndexOrThrow(COL_WEIGHT));
            list.add(new WeightEntry(id, date, wt));
        }
        c.close();
        return list;
    }

    /** Updates a weight entry; returns number of rows affected. */
    public int updateWeight(int id, String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(COL_DATE, date);
        cv.put(COL_WEIGHT, weight);
        return db.update(
                TABLE_WEIGHTS,
                cv,
                COL_ID + "=?",
                new String[]{ String.valueOf(id) }
        );
    }

    /** Deletes a weight entry; returns number of rows deleted. */
    public int deleteWeight(int id) {
        SQLiteDatabase db = getWritableDatabase();
        return db.delete(
                TABLE_WEIGHTS,
                COL_ID + "=?",
                new String[]{ String.valueOf(id) }
        );
    }

    //
    // === Goal methods ===
    //

    /** Stores a one-time goal weight (overwrites any existing). */
    public void setGoal(double goalWt) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_GOAL, null, null);
        ContentValues cv = new ContentValues();
        cv.put(COL_GOAL_WT, goalWt);
        db.insert(TABLE_GOAL, null, cv);
    }

    /** Retrieves the stored goal weight, or -1 if none. */
    public double getGoal() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(
                TABLE_GOAL,
                new String[]{ COL_GOAL_WT },
                null, null, null, null, null
        );
        double result = -1;
        if (c.moveToFirst()) {
            result = c.getDouble(c.getColumnIndexOrThrow(COL_GOAL_WT));
        }
        c.close();
        return result;
    }
}

