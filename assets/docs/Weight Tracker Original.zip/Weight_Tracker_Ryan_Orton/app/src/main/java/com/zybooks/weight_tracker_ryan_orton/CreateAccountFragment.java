package com.zybooks.weight_tracker_ryan_orton;

import android.Manifest;
import android.app.AlertDialog;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

public class CreateAccountFragment extends Fragment {

    private static final int SMS_PERMISSION_REQ = 1001;

    private DBHelper dbHelper;
    private EditText newUsernameEditText;
    private EditText newPasswordEditText;
    private Button   createAccountButton;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_create_account,
                container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper             = new DBHelper(requireContext());
        newUsernameEditText  = view.findViewById(R.id.newUsernameEditText);
        newPasswordEditText  = view.findViewById(R.id.newPasswordEditText);
        createAccountButton  = view.findViewById(R.id.createButton);

        createAccountButton.setOnClickListener(v -> {
            String user = newUsernameEditText.getText().toString().trim();
            String pass = newPasswordEditText.getText().toString().trim();
            if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                Toast.makeText(getContext(),
                        "Please enter username & password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            boolean added = dbHelper.addUser(user, pass);
            if (!added) {
                Toast.makeText(getContext(),
                        "Username already exists",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Prompt for goal weight
            promptForGoalWeight();
            // Request SMS permission if needed
            requestSmsPermissionIfNeeded();

            // Go back to login
            getParentFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, new LoginFragment())
                    .addToBackStack(null)
                    .commit();
        });
    }

    private void promptForGoalWeight() {
        final EditText input = new EditText(getContext());
        input.setInputType(
                InputType.TYPE_CLASS_NUMBER |
                        InputType.TYPE_NUMBER_FLAG_DECIMAL
        );

        new AlertDialog.Builder(requireContext())
                .setTitle("Set Your Goal Weight")
                .setView(input)
                .setPositiveButton("Save", (d, w) -> {
                    String val = input.getText().toString().trim();
                    if (TextUtils.isEmpty(val)) {
                        Toast.makeText(getContext(),
                                "Goal weight not set",
                                Toast.LENGTH_SHORT).show();
                        return;
                    }
                    double goal = Double.parseDouble(val);
                    dbHelper.setGoal(goal);
                    Toast.makeText(getContext(),
                            "Goal saved: " + goal,
                            Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Skip", null)
                .show();
    }

    private void requestSmsPermissionIfNeeded() {
        if (ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQ
            );
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {

        if (requestCode == SMS_PERMISSION_REQ) {
            boolean granted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;
            Toast.makeText(getContext(),
                    granted ? "SMS enabled" : "SMS permission denied",
                    Toast.LENGTH_SHORT).show();
        }
    }
}


