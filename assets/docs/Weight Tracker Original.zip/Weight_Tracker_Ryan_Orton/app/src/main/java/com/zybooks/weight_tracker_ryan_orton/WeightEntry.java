package com.zybooks.weight_tracker_ryan_orton;

public class WeightEntry {
    public final int    id;
    public final String date;
    public final double weight;

    public WeightEntry(int id, String date, double weight) {
        this.id     = id;
        this.date   = date;
        this.weight = weight;
    }
}
