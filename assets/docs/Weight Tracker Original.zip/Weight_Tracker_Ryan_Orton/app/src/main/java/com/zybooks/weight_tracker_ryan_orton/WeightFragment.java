package com.zybooks.weight_tracker_ryan_orton;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class WeightFragment extends Fragment {

    private DBHelper dbHelper;
    private EditText weightEditText;
    private Button   addWeightButton;
    private RecyclerView weightsRecycler;
    private WeightAdapter adapter;
    private double   goalWeight;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_weight, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view,
                              @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        dbHelper        = new DBHelper(requireContext());
        weightEditText  = view.findViewById(R.id.weightEditText);
        addWeightButton = view.findViewById(R.id.addWeightButton);
        weightsRecycler = view.findViewById(R.id.weightsRecyclerView);

        // Grab the one-time goal (or -1 if none)
        goalWeight = dbHelper.getGoal();

        // Set up 2-col grid
        weightsRecycler.setLayoutManager(
                new GridLayoutManager(getContext(), 2));

        // Initial load
        refreshGrid();

        addWeightButton.setOnClickListener(v -> {
            String wstr = weightEditText.getText().toString().trim();
            if (TextUtils.isEmpty(wstr)) {
                Toast.makeText(getContext(),
                        "Please enter a weight", Toast.LENGTH_SHORT).show();
                return;
            }
            double newWeight = Double.parseDouble(wstr);
            String date = new SimpleDateFormat(
                    "yyyy-MM-dd", Locale.US).format(new Date());

            // Get previous entries so we know last weight
            List<WeightEntry> prevEntries = dbHelper.getAllWeights();
            double prevWeight = prevEntries.isEmpty()
                    ? newWeight
                    : prevEntries.get(prevEntries.size() - 1).weight;

            // Insert the new one
            long id = dbHelper.addWeight(date, newWeight);
            if (id == -1) {
                Toast.makeText(getContext(),
                        "Error adding weight", Toast.LENGTH_SHORT).show();
                return;
            }

            weightEditText.setText("");
            Toast.makeText(getContext(),
                    "Weight added", Toast.LENGTH_SHORT).show();

            // Only fire SMS if we actually crossed the goal
            if (goalWeight > 0) {
                boolean crossedDown = (prevWeight > goalWeight && newWeight <= goalWeight);
                boolean crossedUp   = (prevWeight < goalWeight && newWeight >= goalWeight);

                if (crossedDown || crossedUp) {
                    sendGoalSms(newWeight);
                }
            }

            // Refresh UI
            refreshGrid();
        });
    }

    private void refreshGrid() {
        List<WeightEntry> list = dbHelper.getAllWeights();
        adapter = new WeightAdapter(list, new WeightAdapter.OnItemActionListener() {
            @Override
            public void onDelete(int id) {
                dbHelper.deleteWeight(id);
                Toast.makeText(getContext(),
                        "Entry deleted", Toast.LENGTH_SHORT).show();
                refreshGrid();
            }
            @Override
            public void onUpdate(int id) {
                showUpdateDialog(list, id);
            }
        });
        weightsRecycler.setAdapter(adapter);
    }

    private void showUpdateDialog(List<WeightEntry> list, int id) {
    }

    private void sendGoalSms(double weight) {
        if (ContextCompat.checkSelfPermission(requireContext(),
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) return;

        String msg = "Congrats! You’ve hit your goal of "
                + goalWeight + " with a weight of " + weight + ".";
        SmsManager.getDefault()
                .sendTextMessage("5554", null, msg, null, null);
        Toast.makeText(getContext(),
                "Goal SMS sent", Toast.LENGTH_SHORT).show();
    }
}