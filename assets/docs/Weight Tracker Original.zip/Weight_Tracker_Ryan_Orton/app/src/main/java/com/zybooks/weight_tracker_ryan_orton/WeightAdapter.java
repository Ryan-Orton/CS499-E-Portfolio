package com.zybooks.weight_tracker_ryan_orton;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter
        extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {

    /** Callback interface for delete & update actions. */
    public interface OnItemActionListener {
        void onDelete(int id);
        void onUpdate(int id);
    }

    private final List<WeightEntry>    mData;
    private final OnItemActionListener mListener;

    public WeightAdapter(List<WeightEntry> data,
                         OnItemActionListener listener) {
        mData     = data;
        mListener = listener;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(android.R.layout.simple_list_item_2,
                        parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(
            @NonNull ViewHolder holder, int position) {

        WeightEntry entry = mData.get(position);
        holder.dateText.setText(entry.date);
        holder.weightText.setText(String.valueOf(entry.weight));

        // On long-press, show a dialog with Update/Delete choices
        holder.itemView.setOnLongClickListener(v -> {
            new AlertDialog.Builder(v.getContext())
                    .setTitle("Select Action")
                    .setItems(new CharSequence[]{"Update", "Delete"},
                            (dialog, which) -> {
                                if (which == 0) {
                                    mListener.onUpdate(entry.id);
                                }
                                else {
                                    mListener.onDelete(entry.id);
                                }
                            })
                    .show();
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final TextView dateText;
        final TextView weightText;

        ViewHolder(View itemView) {
            super(itemView);
            dateText   = itemView.findViewById(android.R.id.text1);
            weightText = itemView.findViewById(android.R.id.text2);
        }
    }
}